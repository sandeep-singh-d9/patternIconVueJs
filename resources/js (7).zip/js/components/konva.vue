<template>
  <div>
  <svg id="svg" class="data" viewBox="0 0 2000 1000" preserveAspectRatio="xMidYMid meet">
    <g id="viewport">
      <g>
      <path style="fill:#65513C;" d="M233.058,210.95c27.653,0,50.072,22.419,50.072,50.072c0,8.669-2.204,16.823-6.081,23.933h5.28
          c7.218,0,13.07,5.852,13.07,13.07v7.171c0,3.259-2.641,5.9-5.9,5.9h-56.441c-27.655,0-50.074-22.419-50.074-50.074
          C182.984,233.369,205.403,210.95,233.058,210.95z"/>
      <path style="fill:#65513C;" d="M78.038,210.95c-27.654,0-50.073,22.419-50.073,50.072c0,8.669,2.205,16.823,6.082,23.933h-5.28
          c-7.218,0-13.07,5.852-13.07,13.07v7.171c0,3.259,2.641,5.9,5.9,5.9h56.441c27.655,0,50.074-22.419,50.074-50.074
          C128.113,233.369,105.694,210.95,78.038,210.95z"/>
      <path style="fill:#9C7F4D;" d="M103.912,311.096h103.273c22.948,0,41.727-18.778,41.727-41.728v-86.505
          c0-51.564-41.801-93.364-93.365-93.364s-93.364,41.8-93.364,93.364v86.505C62.184,292.318,80.962,311.096,103.912,311.096z"/>
      <path style="fill:#FFFFFF;" d="M62.184,207.95v55.777c12.467-3.153,21.693-14.442,21.693-27.889
          C83.877,222.392,74.651,211.103,62.184,207.95z"/>
      <g>
          <path style="fill:#9C7F4D;" d="M210.947,8.397h-110.8c-24.623,0-44.77,20.146-44.77,44.77v46.872
              c0,55.322,44.848,100.169,100.17,100.169c55.321,0,100.169-44.847,100.169-100.169V53.166
              C255.717,28.543,235.571,8.397,210.947,8.397z"/>
          <path style="fill:#FFFFFF;" d="M193.767,95.523h-76.438c-11.774,0-21.318,9.544-21.318,21.318v42.638
              c0,11.774,9.544,21.319,21.318,21.319s21.318-9.545,21.318-21.319v-21.318h33.801v21.318c0,11.774,9.544,21.319,21.318,21.319
              c11.774,0,21.318-9.545,21.318-21.319v-42.638C215.085,105.067,205.541,95.523,193.767,95.523z"/>
          <g>
              <path style="fill:#FADF8D;" d="M131.8,131.792c-3.284,0-4.629-2.327-2.986-5.172l5.782-10.016c1.643-2.845,4.33-2.845,5.973,0
                  l5.782,10.016c1.642,2.845,0.298,5.172-2.986,5.172H131.8z"/>
              <path style="fill:#FADF8D;" d="M179.296,131.792c3.284,0,4.629-2.327,2.985-5.172l-5.781-10.016c-1.642-2.845-4.33-2.845-5.973,0
                  l-5.782,10.016c-1.643,2.845-0.298,5.172,2.986,5.172H179.296z"/>
              <path style="fill:#826940;" d="M172.667,122.066h-34.24c-7.607,0-13.834,6.225-13.834,13.834v7.549
                  c0,17.097,13.858,30.953,30.955,30.953c17.096,0,30.954-13.856,30.954-30.953V135.9
                  C186.502,128.29,180.276,122.066,172.667,122.066z"/>
          </g>
          <path style="fill:#333E48;" d="M165.539,106.347c-5.062,5.251-13.496,5.399-18.74,0.335l-5.853-5.648
              c-5.247-5.066-3.571-9.21,3.722-9.21h21.62c7.293,0,9.117,4.296,4.054,9.543L165.539,106.347z"/>
          <path style="fill:#65513C;" d="M252.347,51.524c-13.42,0.246-24.591-10.54-24.825-23.957l-0.267-14.968
              c-0.236-13.421,7.341-16.635,16.832-7.143l28.14,28.139c9.492,9.492,6.274,17.457-7.146,17.696L252.347,51.524z"/>
          <path style="fill:#65513C;" d="M58.749,51.524c13.42,0.246,24.591-10.54,24.825-23.957l0.267-14.968
              c0.237-13.421-7.34-16.635-16.831-7.143L38.87,33.595c-9.492,9.492-6.274,17.457,7.145,17.696L58.749,51.524z"/>
          <circle style="fill:#FFFFFF;" cx="207.687" cy="60.347" r="24.161"/>
          <circle style="fill:#333E48;" cx="207.687" cy="60.347" r="8.819"/>
          <circle style="fill:#333E48;" cx="103.409" cy="60.347" r="8.819"/>
      </g>
      <path style="fill:#826940;" d="M130.128,216.124c0-12.094-9.805-21.898-21.898-21.898c-12.094,0-21.898,9.805-21.898,21.898v68.83
          H68.179c-7.219,0-13.069,5.852-13.069,13.07v7.171c0,3.259,2.64,5.9,5.899,5.9h56.05c7.218,0,13.069-5.853,13.069-13.071V216.124z"
          />
      <path style="fill:#826940;" d="M180.968,216.124c0-12.094,9.805-21.898,21.898-21.898c12.094,0,21.898,9.805,21.898,21.898v68.83
          h18.152c7.219,0,13.069,5.852,13.069,13.07v7.171c0,3.259-2.64,5.9-5.899,5.9h-56.05c-7.218,0-13.069-5.853-13.069-13.071v-81.9
          H180.968z"/>
  </g>
    </g>  
  </svg>
  <svg id="svg" class="data" viewBox="0 0 2000 1000" preserveAspectRatio="xMidYMid meet">
    <g id="viewport">
      <g>
      <path style="fill:#65513C;" d="M233.058,210.95c27.653,0,50.072,22.419,50.072,50.072c0,8.669-2.204,16.823-6.081,23.933h5.28
          c7.218,0,13.07,5.852,13.07,13.07v7.171c0,3.259-2.641,5.9-5.9,5.9h-56.441c-27.655,0-50.074-22.419-50.074-50.074
          C182.984,233.369,205.403,210.95,233.058,210.95z"/>
      <path style="fill:#65513C;" d="M78.038,210.95c-27.654,0-50.073,22.419-50.073,50.072c0,8.669,2.205,16.823,6.082,23.933h-5.28
          c-7.218,0-13.07,5.852-13.07,13.07v7.171c0,3.259,2.641,5.9,5.9,5.9h56.441c27.655,0,50.074-22.419,50.074-50.074
          C128.113,233.369,105.694,210.95,78.038,210.95z"/>
      <path style="fill:#9C7F4D;" d="M103.912,311.096h103.273c22.948,0,41.727-18.778,41.727-41.728v-86.505
          c0-51.564-41.801-93.364-93.365-93.364s-93.364,41.8-93.364,93.364v86.505C62.184,292.318,80.962,311.096,103.912,311.096z"/>
      <path style="fill:#FFFFFF;" d="M62.184,207.95v55.777c12.467-3.153,21.693-14.442,21.693-27.889
          C83.877,222.392,74.651,211.103,62.184,207.95z"/>
      <g>
          <path style="fill:#9C7F4D;" d="M210.947,8.397h-110.8c-24.623,0-44.77,20.146-44.77,44.77v46.872
              c0,55.322,44.848,100.169,100.17,100.169c55.321,0,100.169-44.847,100.169-100.169V53.166
              C255.717,28.543,235.571,8.397,210.947,8.397z"/>
          <path style="fill:#FFFFFF;" d="M193.767,95.523h-76.438c-11.774,0-21.318,9.544-21.318,21.318v42.638
              c0,11.774,9.544,21.319,21.318,21.319s21.318-9.545,21.318-21.319v-21.318h33.801v21.318c0,11.774,9.544,21.319,21.318,21.319
              c11.774,0,21.318-9.545,21.318-21.319v-42.638C215.085,105.067,205.541,95.523,193.767,95.523z"/>
          <g>
              <path style="fill:#FADF8D;" d="M131.8,131.792c-3.284,0-4.629-2.327-2.986-5.172l5.782-10.016c1.643-2.845,4.33-2.845,5.973,0
                  l5.782,10.016c1.642,2.845,0.298,5.172-2.986,5.172H131.8z"/>
              <path style="fill:#FADF8D;" d="M179.296,131.792c3.284,0,4.629-2.327,2.985-5.172l-5.781-10.016c-1.642-2.845-4.33-2.845-5.973,0
                  l-5.782,10.016c-1.643,2.845-0.298,5.172,2.986,5.172H179.296z"/>
              <path style="fill:#826940;" d="M172.667,122.066h-34.24c-7.607,0-13.834,6.225-13.834,13.834v7.549
                  c0,17.097,13.858,30.953,30.955,30.953c17.096,0,30.954-13.856,30.954-30.953V135.9
                  C186.502,128.29,180.276,122.066,172.667,122.066z"/>
          </g>
          <path style="fill:#333E48;" d="M165.539,106.347c-5.062,5.251-13.496,5.399-18.74,0.335l-5.853-5.648
              c-5.247-5.066-3.571-9.21,3.722-9.21h21.62c7.293,0,9.117,4.296,4.054,9.543L165.539,106.347z"/>
          <path style="fill:#65513C;" d="M252.347,51.524c-13.42,0.246-24.591-10.54-24.825-23.957l-0.267-14.968
              c-0.236-13.421,7.341-16.635,16.832-7.143l28.14,28.139c9.492,9.492,6.274,17.457-7.146,17.696L252.347,51.524z"/>
          <path style="fill:#65513C;" d="M58.749,51.524c13.42,0.246,24.591-10.54,24.825-23.957l0.267-14.968
              c0.237-13.421-7.34-16.635-16.831-7.143L38.87,33.595c-9.492,9.492-6.274,17.457,7.145,17.696L58.749,51.524z"/>
          <circle style="fill:#FFFFFF;" cx="207.687" cy="60.347" r="24.161"/>
          <circle style="fill:#333E48;" cx="207.687" cy="60.347" r="8.819"/>
          <circle style="fill:#333E48;" cx="103.409" cy="60.347" r="8.819"/>
      </g>
      <path style="fill:#826940;" d="M130.128,216.124c0-12.094-9.805-21.898-21.898-21.898c-12.094,0-21.898,9.805-21.898,21.898v68.83
          H68.179c-7.219,0-13.069,5.852-13.069,13.07v7.171c0,3.259,2.64,5.9,5.899,5.9h56.05c7.218,0,13.069-5.853,13.069-13.071V216.124z"
          />
      <path style="fill:#826940;" d="M180.968,216.124c0-12.094,9.805-21.898,21.898-21.898c12.094,0,21.898,9.805,21.898,21.898v68.83
          h18.152c7.219,0,13.069,5.852,13.069,13.07v7.171c0,3.259-2.64,5.9-5.899,5.9h-56.05c-7.218,0-13.069-5.853-13.069-13.071v-81.9
          H180.968z"/>
  </g>
    </g>  
  </svg>
  
  <svg id="svg-scrim" class="svg svg-scrim">  
    <circle id="pivot" class="pivot" cx="0" cy="0" r="6" />
  </svg>
  
      <button id="reset" style="display:none;" >  </button>
  
  </div>
</template>

<script>
const width = window.innerWidth;
const height = window.innerHeight;
export default {
  data() {
    return {
      list: [],
      dragItemId: null,
      configKonva: {
        width: width,
        height: height
      }
    };
  },
  mounted(){
    $( function() {
        var test = document.querySelectorAll(".data");
    var svg = test[0]
     var  i;
    for (i = 0; i < svg.length; i++) {
        
    }
        var point = svg.createSVGPoint();
        var startClient = svg.createSVGPoint();
        var startGlobal = svg.createSVGPoint();

        var viewBox = svg.viewBox.baseVal;
            var reset = document.querySelector("#reset");
            var pivot = document.querySelector("#pivot");
            var proxy = document.createElement("div");
            var viewport = document.querySelector("#viewport");

            var rotateThreshold = 4;
            var reachedThreshold = false;

            // var point = svg.createSVGPoint();
            // var startClient = svg.createSVGPoint();
            // var startGlobal = svg.createSVGPoint();

            // var viewBox = svg.viewBox.baseVal;

            var cachedViewBox = {
            x: viewBox.x,
            y: viewBox.y,
            width: viewBox.width,
            height: viewBox.height
            };

            var zoom = {
            animation: new TimelineLite(),
            scaleFactor: 1.6,
            duration: 0.5,
            ease: Power2.easeOut,
            };

            TweenLite.set(pivot, { scale: 0 });

            var resetAnimation = new TimelineLite();
            var pivotAnimation = TweenLite.to(pivot, 0.1, {
            alpha: 1,
            scale: 1,
            paused: true,
            });

            var pannable = new Draggable(proxy, {
            throwResistance: 3000,
            trigger: svg,
            throwProps: false,
            onPress: selectDraggable,
            onDrag: updateViewBox,
            onThrowUpdate: updateViewBox,
            });

            var rotatable = new Draggable(viewport, {
            type: "rotation",
            trigger: svg,
            throwProps: false,
            liveSnap: false,
            snap: checkThreshold,
            onPress: selectDraggable,
            });

            rotatable.disable();

            reset.addEventListener("click", resetViewport);
            window.addEventListener("wheel", onWheel);
            window.addEventListener("resize", function() {
            pivotAnimation.reverse();
            });

            window.addEventListener("contextmenu", function(event) {
            event.preventDefault();
                event.stopPropagation();
            return false;
            });

            //
            // ON WHEEL
            // =========================================================================== 
            function onWheel(event) {
            event.preventDefault();
            
            pivotAnimation.reverse();
            
            var normalized;  
            var delta = event.wheelDelta;

            if (delta) {
                normalized = (delta % 120) == 0 ? delta / 120 : delta / 12;
            } else {
                delta = event.deltaY || event.detail || 0;
                normalized = -(delta % 3 ? delta * 10 : delta / 3);
            }
            
            var scaleDelta = normalized > 0 ? 1 / zoom.scaleFactor : zoom.scaleFactor;
            
            point.x = event.clientX;
            point.y = event.clientY;
            
            var startPoint = point.matrixTransform(svg.getScreenCTM().inverse());
                
            var fromVars = {
                ease: zoom.ease,
                x: viewBox.x,
                y: viewBox.y,
                width: viewBox.width,
                height: viewBox.height,
            };
            
            viewBox.x -= (startPoint.x - viewBox.x) * (scaleDelta - 1);
            viewBox.y -= (startPoint.y - viewBox.y) * (scaleDelta - 1);
            viewBox.width *= scaleDelta;
            viewBox.height *= scaleDelta;
                
            zoom.animation = TweenLite.from(viewBox, zoom.duration, fromVars);  
            }

            //
            // SELECT DRAGGABLE
            // =========================================================================== 
            function selectDraggable(event) {
            
            if (resetAnimation.isActive()) {
                resetAnimation.kill();
            }
                
            startClient.x = this.pointerX;
            startClient.y = this.pointerY;
            startGlobal = startClient.matrixTransform(svg.getScreenCTM().inverse());
            
            // Right mouse button
            if (event.button === 2) {
                
                reachedThreshold = false;
                
                TweenLite.set(viewport, { 
                svgOrigin: startGlobal.x + " " + startGlobal.y
                });
                
                TweenLite.set(pivot, { 
                x: this.pointerX, 
                y: this.pointerY
                });
                
                pannable.disable();
                rotatable.enable().update().startDrag(event);
                pivotAnimation.play(0);
                
            } else {
                
                TweenLite.set(proxy, { 
                x: this.pointerX, 
                y: this.pointerY
                });
                
                rotatable.disable();
                pannable.enable().update().startDrag(event);
                pivotAnimation.reverse();
            }
            }

            //
            // RESET VIEWPORT
            // =========================================================================== 
            function resetViewport() {
                
            var duration = 0.8;
            var ease = Power3.easeOut;
            
            pivotAnimation.reverse();
            
            if (pannable.tween) {
                pannable.tween.kill();
            }
            
            if (rotatable.tween) {
                rotatable.tween.kill();
            }
                
            resetAnimation.clear()
                .to(viewBox, duration, {
                x: cachedViewBox.x,
                y: cachedViewBox.y,
                width: cachedViewBox.width,
                height: cachedViewBox.height,
                ease: ease
                }, 0)
                .to(viewport, duration, {
                attr: { transform: "matrix(1,0,0,1,0,0)" },
                // rotation: "0_short",
                smoothOrigin: false,
                svgOrigin: "0 0",
                ease: ease
                }, 0)
            }

            //
            // CHECK THRESHOLD
            // =========================================================================== 
            function checkThreshold(value) {
            
            if (reachedThreshold) {
                return value;
            }
            
            var dx = Math.abs(this.pointerX - startClient.x);
            var dy = Math.abs(this.pointerY - startClient.y);
            
            if (dx > rotateThreshold || dy > rotateThreshold || this.isThrowing) {
                reachedThreshold = true;
                return value;
            }
                
            return this.rotation;
            }

            //
            // UPDATE VIEWBOX
            // =========================================================================== 
            function updateViewBox() {
            
            if (zoom.animation.isActive()) {
                return;
            }
            
            point.x = this.x;
            point.y = this.y;
            
            var moveGlobal = point.matrixTransform(svg.getScreenCTM().inverse());
                
            viewBox.x -= (moveGlobal.x - startGlobal.x);
            viewBox.y -= (moveGlobal.y - startGlobal.y); 
            }
            } );
  },
  methods: {
    handleDragstart(e) {
      // save drag element:
      this.dragItemId = e.target.id();
      // move current element to the top:
      const item = this.list.find(i => i.id === this.dragItemId);
      const index = this.list.indexOf(item);
      this.list.splice(index, 1);
      this.list.push(item);
    },
    handleDragend(e) {
      this.dragItemId = null;
    }
  },
  // mounted() {
  //   for (let n = 0; n < 30; n++) {
  //     this.list.push({
  //       id: Math.round(Math.random() * 10000).toString(),
  //       x: Math.random() * width,
  //       y: Math.random() * height,
  //       rotation: Math.random() * 180,
  //       scale: Math.random()
  //     });
  //   }
  // }
};
</script>

<style scoped>
.svg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  cursor: move;
}
.svg-scrim {
  pointer-events: none;
  z-index: 5;
}
.pivot {
  fill: #ffc107;
  stroke: rgba(0,0,0,0.5);
  stroke-width: 2;
  opacity: 0;
}
</style>