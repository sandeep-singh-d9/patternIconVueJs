<template>
  <div>
   <svg  version="1.1" baseProfile="basic" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  style="display: none;">
    <symbol :id="'ic'+this.ValueId">

       <path d="m227.574219 63.832031 28.425781-14.652343c141.242188 35.308593 167.722656 132.414062 167.722656 132.414062h-423.722656l119.261719-61.707031zm0 0" fill="#fac176" />
    <path :style="{fill:'rgba(241, 141, 70 ,1)' }" :class="this.ValueId+'_color2'"  d="m0 181.59375h423.722656l-40.261718 128.882812c-2.3125 7.355469-9.136719 12.359376-16.851563 12.355469h-340.125zm0 0" />
    <path d="m182.996094 17.046875c-8.386719 21.890625-36.457032 44.929687-53.847656 57.554687-12.207032 8.8125-17.339844 24.488282-12.714844 38.8125 4.628906 14.324219 17.964844 24.035157 33.015625 24.039063h53.585937zm0 0" fill="#e6e7e8" />
    <path d="m256 102.761719c-.003906 19.15625-15.535156 34.6875-34.691406 34.691406h-18.273438c-35.3125-14.125-25.425781-90.570313-20.039062-120.40625.007812-.066406.039062-.128906.089844-.175781 1.429687-3.785156 2.207031-7.785156 2.292968-11.832032 0 25.070313 35.574219 54.554688 56.230469 69.5625 9.007813 6.5625 14.351563 17.019532 14.390625 28.160157zm0 0" fill="#ecf0f1" />
    <path :style="{fill:'rgba(127, 110, 93 , 1)' }" :class="this.ValueId+'_color1'" d="m26.484375 322.832031h340.125c7.714844.003907 14.539063-5 16.851563-12.355469l40.261718-128.882812c9.765625-27.875 26.167969-52.949219 47.792969-73.058594 5.035156-4.625 11.789063-6.902344 18.597656-6.269531 6.804688.632813 13.023438 4.117187 17.121094 9.589844l.308594.414062c6.246093 8.308594 6.210937 19.753907-.082031 28.027344-41.945313 55.394531-84.742188 183.179687-97.550782 223.257813-2.351562 7.296874-9.140625 12.246093-16.808594 12.246093h-348.964843c-9.75 0-17.652344-7.90625-17.652344-17.65625z"/>
    <path d="m506.96875 111.5c-4.148438-5.34375-10.34375-8.707031-17.085938-9.277344-6.742187-.570312-13.414062 1.707032-18.402343 6.277344-21.601563 20.140625-37.988281 45.222656-47.757813 73.09375 0 0-26.480468-97.105469-167.722656-132.414062v-21.894532c-.046875-4.671875 1.800781-9.160156 5.121094-12.445312l.792968-.796875c9.269532-8.5625 30.898438-20.65625 73.535157-9.355469 55.878906 14.828125 147.949219 76.886719 171.519531 106.8125zm0 0" fill="#cbb292" />
    <path d="m403.949219 81.398438c-1.519531 1.78125-3.6875 2.882812-6.019531 3.0625-2.335938.183593-4.648438-.570313-6.425782-2.089844-55.703125-47.757813-127.03125-50.671875-134.972656-50.847656-.183594.011718-.363281-.015626-.53125-.089844v-4.148438c-.046875-4.671875 1.800781-9.160156 5.121094-12.445312l.792968-.796875c19.863282 1.238281 87.21875 8.742187 141.066407 54.910156 1.777343 1.519531 2.878906 3.6875 3.0625 6.019531.183593 2.335938-.570313 4.648438-2.09375 6.425782zm0 0" fill="#fdd7ad" />
    <g>
        <path :style="{fill:'rgba(210, 86, 39 , 1)' }" :class="this.ValueId+'_color3'" d="m88.277344 234.558594c0 9.75-7.90625 17.652344-17.65625 17.652344s-17.65625-7.902344-17.65625-17.652344 7.90625-17.65625 17.65625-17.65625 17.65625 7.90625 17.65625 17.65625zm0 0" />
        <path :style="{fill:'rgba(210, 86, 39 , 1)' }" :class="this.ValueId+'_color3'" d="m194.207031 252.210938c0 19.503906-15.808593 35.3125-35.308593 35.3125-19.503907 0-35.3125-15.808594-35.3125-35.3125 0-19.5 15.808593-35.308594 35.3125-35.308594 19.5 0 35.308593 15.808594 35.308593 35.308594zm0 0" />
        <path :style="{fill:'rgba(210, 86, 39 , 1)' }" :class="this.ValueId+'_color3'" d="m273.65625 234.558594c0 9.75-7.90625 17.652344-17.65625 17.652344s-17.65625-7.902344-17.65625-17.652344 7.90625-17.65625 17.65625-17.65625 17.65625 7.90625 17.65625 17.65625zm0 0" />
        <path :style="{fill:'rgba(210, 86, 39 , 1)' }" :class="this.ValueId+'_color3'" d="m353.101562 269.867188c0 14.625-11.855468 26.484374-26.480468 26.484374s-26.484375-11.859374-26.484375-26.484374 11.859375-26.480469 26.484375-26.480469 26.480468 11.855469 26.480468 26.480469zm0 0" />
        <path :style="{fill:'rgba(210, 86, 39 , 1)' }" :class="this.ValueId+'_color3'" d="m88.277344 296.351562c-2.351563.023438-4.609375-.898437-6.269532-2.558593-1.660156-1.664063-2.582031-3.921875-2.558593-6.269531-.035157-1.160157.207031-2.308594.707031-3.355469.445312-1.070313 1.074219-2.054688 1.851562-2.914063.828126-.816406 1.824219-1.445312 2.914063-1.851562 3.285156-1.382813 7.082031-.652344 9.621094 1.851562.78125.859375 1.40625 1.84375 1.855469 2.914063.449218 1.0625.691406 2.203125.703124 3.355469-.011718.5625-.074218 1.125-.183593 1.675781-.082031.585937-.257813 1.152343-.53125 1.679687-.175781.539063-.445313 1.046875-.792969 1.5-.351562.527344-.707031.96875-1.058594 1.410156-1.691406 1.609376-3.925781 2.523438-6.257812 2.5625zm0 0" />
        <path :style="{fill:'rgba(210, 86, 39 , 1)' }" :class="this.ValueId+'_color3'" d="m238.34375 296.351562c-2.347656.023438-4.605469-.898437-6.265625-2.558593-1.664063-1.664063-2.585937-3.921875-2.5625-6.269531-.03125-1.160157.210937-2.308594.707031-3.355469.449219-1.070313 1.074219-2.054688 1.855469-2.914063.828125-.816406 1.820313-1.445312 2.914063-1.851562 3.285156-1.382813 7.082031-.652344 9.621093 1.851562.777344.859375 1.40625 1.84375 1.851563 2.914063.453125 1.0625.695312 2.203125.707031 3.355469-.015625.5625-.078125 1.125-.183594 1.675781-.082031.585937-.261719 1.152343-.53125 1.679687-.175781.539063-.445312 1.046875-.792969 1.5-.355468.527344-.707031.96875-1.058593 1.410156-1.691407 1.609376-3.925781 2.523438-6.261719 2.5625zm0 0" />
        <path :style="{fill:'rgba(210, 86, 39 , 1)' }" :class="this.ValueId+'_color3'" d="m370.757812 225.730469c-2.347656.023437-4.605468-.898438-6.265624-2.558594-1.664063-1.660156-2.585938-3.921875-2.5625-6.269531-.03125-1.15625.210937-2.308594.707031-3.355469.449219-1.070313 1.074219-2.054687 1.855469-2.910156.828124-.820313 1.820312-1.449219 2.910156-1.855469 3.289062-1.382812 7.085937-.652344 9.625 1.855469.777344.855469 1.40625 1.839843 1.851562 2.910156.453125 1.0625.691406 2.203125.707032 3.355469-.015626.5625-.078126 1.125-.183594 1.675781-.082032.585937-.261719 1.152344-.53125 1.679687-.175782.542969-.445313 1.050782-.792969 1.5-.355469.53125-.707031.972657-1.0625 1.414063-1.691406 1.605469-3.921875 2.519531-6.257813 2.558594zm0 0" />
    </g>
    </symbol>
   </svg>

  <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
     <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    
     <div :id="svgName+dynamicIndex" v-if="this.$store.state.dynamicName ===svgName+dynamicIndex">
        <button :style="{background:'rgba(127, 110, 93,1)' , width:'50px' ,height:'50px'}" @click="ShowElement(getterHippoBg1)" :class="this.ValueId+'_color1btn'"></button>
               
               
        <button :style="{backgroundColor:'rgba(241, 141, 70,1)' , width:'50px' , height:'50px'}" @click="ShowElement1(getterHippoBg2)" :class="this.ValueId+'_color2btn'"></button>
    
    
        <button :style="{backgroundColor:'rgba(210, 86, 39, 1)' , width:'50px' , height:'50px'}" @click="ShowElement2(getterHippoBg3)" :class="this.ValueId+'_color3btn'"></button>
    </div>
    <Colorpicker v-if="this.showColorPicker" :colorElement ="this.colorValue" :valueElement="this.clickedInput"/>
     <button v-if="this.showColorPicker" @click="hideElement">Close</button>
  </div>
</template>

<script>
import ColorButton from '../ColorButton'
import Colorpicker from '../colorPickerComponent'
import {
    mapState,
    mapActions,
    mapGetters,
    mapMutations
} from 'vuex';
export default {
  props:['dynamicBackground' ,'dynamicBackgroundOne', 'dynamicBackgroundTwo' , 'dynamicIndex', 'ValueId' , 'svgName'],
  components:{
        ColorButton,
        Colorpicker
    },
   computed: {
        ...mapState([ 
            'background' ,
            'background1',
            'background2', 
        ]),
        getterHippoBg1:{
            get(){
             console.log(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0])
              
                  return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
            

            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg2:{
            get(){
               
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1
                
            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg3:{
            get(){
                
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2
                 
            }, 
            set(newValue){
                console.log(newValue)
            }
        }
    },
    data(){
        return{
           colorValue:'',
           showColorPicker:false,
           clickedInput:''
        }
    },
    methods:{
    ...mapActions([
    'ACTION_CHANGE_STATE',
    ]),
    ...mapMutations([
        
    ]),
    
    ShowElement(value){
        //   this.colorValue = value
          console.log(value, 'ssss')
          var ColorValue = this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
          this.colorValue = 'rgba('+ColorValue+')'
          this.showColorPicker=true
          this.clickedInput= 'One'
        //  console.log( , 'value')
      },
      ShowElement1(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1+')'
        console.log('sjahsja')
         this.clickedInput= 'Two'
          this.showColorPicker=true
      },
      ShowElement2(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2+')'
        console.log('sjahsja')
         this.clickedInput= 'Third'
          this.showColorPicker=true
      },
      hideElement(){
        this.showColorPicker=false
      }, 
    }
}
</script>

<style>

</style>