<template>
<div id="menu">
    <div class="container">
        <ul>
            <li>
                <label for="search-opt" class="active">
                    <svg class="icon-search">
                        <use xlink:href="#icon-search"></use>
                    </svg>
                    <span>search</span>
                </label>
            </li>
            <li>
                <label for="bg">
                    <svg class="icon-bg">
                        <use xlink:href="#icon-bg"></use>
                    </svg>
                    <span>bg</span>
                </label>
            </li>
            <li>
                <label for="export">
                    <svg class="icon-download">
                        <use xlink:href="#icon-download"></use>
                    </svg>
                    <span>Download</span>
                </label>
            </li>
        </ul>
    </div>
</div>
  
</template>

<script>
export default {

}
</script>

<style>

</style>