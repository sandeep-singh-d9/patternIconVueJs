<template>
  <div>
      <svg  version="1.1" baseProfile="basic" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  style="display: none;">
    <symbol :id="'ic'+this.ValueId">
      <g>
	<g>
		<path  :style="{fill:'rgba(101, 81, 60 , 1)' }" :class="this.ValueId+'_color3'" d="M185.474,93.505v135.128c0,25.607,20.76,46.367,46.368,46.367v37.1h-74.766
			c-37.014,0-67.02-30.007-67.02-67.02v-23.175c0-18.609-11.606-34.509-27.975-40.854l-0.001,0.003
			C25.928,168.396,0,133.978,0,93.505C0,42.288,41.52,0.768,92.737,0.768S185.474,42.288,185.474,93.505z"/>
		<path style="fill:#E1CB81;" d="M92.737,0.768c8.29,0,16.323,1.094,23.97,3.135c32.169,15.985,53.879,49.171,53.879,86.959v137.096
			c0,24.285,19.758,44.042,44.043,44.042h0.796c5.104,1.933,10.634,3,16.416,3v3H214.63c-27.594,0-50.043-22.449-50.043-50.042
			V90.862c0-44.998-32.796-83.057-76.845-89.959C89.396,0.815,91.061,0.768,92.737,0.768z"/>
	</g>
	<path  :style="{fill:'rgba(156, 127, 77, 1)' }" :class="this.ValueId+'_color2'" d="M200.74,208.506V66.555c0-11.966,9.697-21.657,21.66-21.66c11.96,0,21.657,9.694,21.657,21.658
		v7.991c10.243-5.017,21.754-7.842,33.929-7.842h14.174c42.662,0,77.246,34.584,77.246,77.246c0,28.158-15.072,52.79-37.584,66.289
		c17.323,17.129,28.06,40.906,28.06,67.193c0,52.191-42.309,94.5-94.5,94.5s-94.5-42.309-94.5-94.5
		C170.881,250.245,182.364,225.746,200.74,208.506z"/>
	<circle style="fill:#333E48;" cx="315.436" cy="124.156" r="8.291"/>
	<g>
		<path style="fill:#333E48;" d="M369.817,132.986c0-1.646-1.334-2.98-2.98-2.98l-5.19,0.064c-5.468,0.022-6.711,3.137-2.762,6.917
			l4.405,4.219c1.828,1.752,4.166,2.66,6.525,2.741L369.817,132.986L369.817,132.986z"/>
	</g>
	<path   :style="{fill:'rgba(130, 105, 64,1)' }" :class="this.ValueId+'_color1'" d="M235.452,246.528c35.661,0,64.57,28.909,64.57,64.569v28.419h23.95
		c9.985,0,18.079,8.094,18.079,18.076c0,9.984-8.093,18.078-18.079,18.078H267.87c-0.006,0-0.013-0.001-0.02-0.001h-32.398
		c-35.662,0-64.571-28.909-64.571-64.572C170.881,275.437,199.79,246.528,235.452,246.528z"/>
	<path :style="{fill:'rgba(130, 105, 64,1)' }" :class="this.ValueId+'_color1'" d="M371.142,268.699c7.061,7.061,7.06,18.507,0.001,25.565c-7.06,7.06-18.506,7.061-25.566,0
		l-32.618-32.618c-7.06-7.061-7.059-18.505,0.001-25.565c7.059-7.059,18.503-7.061,25.563,0L371.142,268.699z"/>
</g>
    </symbol>
    </svg>
     <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
     <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>

    <div :id="svgName+dynamicIndex" v-if="this.$store.state.dynamicName ===svgName+dynamicIndex">
        <button :style="{background:'rgba(130, 105, 64,1)' , width:'50px' ,height:'50px'}" @click="ShowElement(getterHippoBg1)" :class="this.ValueId+'_color1btn'"></button>
               
               
        <button :style="{backgroundColor:'rgba(156, 127, 77, 1)' , width:'50px' , height:'50px'}" @click="ShowElement1(getterHippoBg2)" :class="this.ValueId+'_color2btn'"></button>
    
    
        <button :style="{backgroundColor:'rgba(101, 81, 60 , 1)' , width:'50px' , height:'50px'}" @click="ShowElement2(getterHippoBg3)" :class="this.ValueId+'_color3btn'"></button>
    </div>
    <Colorpicker v-if="this.showColorPicker" :colorElement ="this.colorValue" :valueElement="this.clickedInput"/>
     <button v-if="this.showColorPicker" @click="hideElement">Close</button>
  </div>
</template>

<script>
import ColorButton from '../ColorButton'
import Colorpicker from '../colorPickerComponent'
import {
    mapState,
    mapActions,
    mapGetters,
    mapMutations
} from 'vuex';
export default {
  props:['dynamicBackground' ,'dynamicBackgroundOne', 'dynamicBackgroundTwo' , 'dynamicIndex', 'ValueId' , 'svgName'],
  components:{
        ColorButton,
        Colorpicker
    },
   computed: {
        ...mapState([ 
            'background' ,
            'background1',
            'background2', 
        ]),
        getterHippoBg1:{
            get(){
             console.log(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0])
              if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                  return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
              }

            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg2:{
            get(){
                 if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1
                 }
            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg3:{
            get(){
                 if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2
                 }
            }, 
            set(newValue){
                console.log(newValue)
            }
        }
    },
    data(){
        return{
           colorValue:'',
           showColorPicker:false,
           clickedInput:''
        }
    },
    methods:{
    ...mapActions([
    'ACTION_CHANGE_STATE',
    ]),
    ...mapMutations([
        
    ]),
    
    ShowElement(value){
        //   this.colorValue = value
          console.log(value, 'ssss')
          var ColorValue = this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
          this.colorValue = 'rgba('+ColorValue+')'
          this.showColorPicker=true
          this.clickedInput= 'One'
        //  console.log( , 'value')
      },
      ShowElement1(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1+')'
        console.log('sjahsja')
         this.clickedInput= 'Two'
          this.showColorPicker=true
      },
      ShowElement2(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2+')'
        console.log('sjahsja')
         this.clickedInput= 'Third'
          this.showColorPicker=true
      },
      hideElement(){
        this.showColorPicker=false
      }, 
    }
}
</script>

<style>

</style>