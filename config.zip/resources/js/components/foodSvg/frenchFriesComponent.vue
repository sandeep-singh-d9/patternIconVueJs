<template>
  <div>
    <svg  version="1.1" baseProfile="basic" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  style="display: none;">
    <symbol :id="'ic'+this.ValueId">
        <path :style="{fill:'rgba(48, 60, 66, 1)' }" :class="this.ValueId+'_color3'" d="M445.349,174.302c-2.021-2.313-4.937-3.635-8.021-3.635h-10.666V53.333
	c0-5.896-4.771-10.667-10.666-10.667h-53.332V32c0-5.896-4.771-10.667-10.666-10.667h-53.332V10.667
	C298.665,4.771,293.895,0,287.999,0h-63.998h-63.998c-5.896,0-10.666,4.771-10.666,10.667v32H96.005
	c-5.896,0-10.666,4.771-10.666,10.667v117.333H74.672c-3.083,0-6,1.323-8.021,3.635c-2.021,2.323-2.958,5.396-2.562,8.438
	l38.978,292.24c2.812,21.104,20.999,37.021,42.29,37.021h221.285c21.291,0,39.478-15.917,42.311-37.031l38.957-292.229
	C448.307,179.698,447.369,176.625,445.349,174.302z"/>
<g>
	<path  :style="{fill:'rgba(255, 202, 40, 1)' }" :class="this.ValueId+'_color1'" d="M405.339,170.667h-36.563c-2.118,0-4.053,0.704-6.104,1.009V64h42.667V170.667z"/>
	<path  :style="{fill:'rgba(255, 202, 40, 1)' }" :class="this.ValueId+'_color1'" d="M341.339,42.667v138.471c-6.197,5.294-11.108,12.126-13.396,20.32
		c-4.763,17.035-15.422,31.201-29.271,40.883V42.667H341.339z"/>
	<path  :style="{fill:'rgba(255, 202, 40, 1)' }" :class="this.ValueId+'_color1'" d="M277.339,21.333v231.352c-6.826,2.053-13.957,3.315-21.333,3.315
		c-7.376,0-14.508-1.262-21.333-3.315V21.333H277.339z"/>
	<path  :style="{fill:'rgba(255, 202, 40, 1)' }" :class="this.ValueId+'_color1'" d="M170.672,21.333h42.667v221.008c-13.849-9.682-24.508-23.848-29.271-40.883
		c-2.288-8.194-7.199-15.026-13.396-20.32V21.333z"/>
	<path  :style="{fill:'rgba(255, 202, 40, 1)' }" :class="this.ValueId+'_color1'" d="M106.672,64h42.667v107.676c-2.049-0.305-3.987-1.009-6.104-1.009h-36.563V64z"/>
</g>
<path style="opacity:0.1;enable-background:new    ;" d="M317.651,198.594c-3.333,11.966-10.143,22.208-18.979,30.138v13.609
	c13.849-9.682,24.508-23.848,29.271-40.883c2.288-8.194,7.199-15.026,13.396-20.32v-13.323
	C330.085,174.621,321.356,185.384,317.651,198.594z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M405.339,170.667V160h-36.563c-2.07,0-4.083,0.271-6.104,0.507v11.169
	c2.051-0.305,3.986-1.009,6.104-1.009H405.339z"/>
<path  :style="{fill:'rgba(211, 47, 47, 1)' }" :class="this.ValueId+'_color2'" d="M387.818,472.146c-1.417,10.563-10.521,18.521-21.167,18.521H145.36
	c-10.646,0-19.75-7.958-21.146-18.51L86.86,192h56.375c9.458,0,17.792,6.25,20.292,15.188
	c11.521,41.302,49.563,70.146,92.479,70.146s80.958-28.844,92.479-70.146c2.5-8.938,10.833-15.188,20.292-15.188h56.375
	L387.818,472.146z"/>
<path style="opacity:0.2;fill:#FFFFFF;enable-background:new    ;" d="M147.963,472.156L117.339,192H86.86l37.354,280.156
	c1.396,10.552,10.5,18.51,21.146,18.51h19.938C156.569,490.667,149.106,482.708,147.963,472.156z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M394.672,192l-30.605,280.146c-1.161,10.563-8.625,18.521-17.353,18.521
	h19.938c10.646,0,19.75-7.958,21.167-18.521L425.151,192H394.672z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M277.339,252.685v-11.091c-6.732,2.395-13.91,3.74-21.333,3.74
	c-7.423,0-14.602-1.345-21.333-3.74v11.091c6.826,2.053,13.957,3.315,21.333,3.315C263.382,256,270.513,254.738,277.339,252.685z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M213.339,242.341v-13.612c-8.841-7.935-15.658-18.186-19-30.167
	c-3.693-13.191-12.417-23.945-23.667-30.749v13.324c6.197,5.294,11.108,12.126,13.396,20.32
	C188.831,218.493,199.49,232.659,213.339,242.341z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M149.339,171.676v-11.169c-2.021-0.236-4.034-0.507-6.104-0.507h-36.563
	v10.667h36.563C145.352,170.667,147.289,171.371,149.339,171.676z"/>
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="-45.1613" y1="638.824" x2="-25.0062" y2="629.425" gradientTransform="matrix(21.3333 0 0 -21.3333 996.3334 13791.667)">
	<stop  offset="0" style="stop-color:#FFFFFF;stop-opacity:0.2"/>
	<stop  offset="1" style="stop-color:#FFFFFF;stop-opacity:0"/>
</linearGradient>
<path style="fill:url(#SVGID_1_);" d="M445.349,174.302c-2.021-2.313-4.937-3.635-8.021-3.635h-10.666V53.333
	c0-5.896-4.771-10.667-10.666-10.667h-53.332V32c0-5.896-4.771-10.667-10.666-10.667h-53.332V10.667
	C298.665,4.771,293.895,0,287.999,0h-63.998h-63.998c-5.896,0-10.666,4.771-10.666,10.667v32H96.005
	c-5.896,0-10.666,4.771-10.666,10.667v117.333H74.672c-3.083,0-6,1.323-8.021,3.635c-2.021,2.323-2.958,5.396-2.562,8.438
	l38.978,292.24c2.812,21.104,20.999,37.021,42.29,37.021h221.285c21.291,0,39.478-15.917,42.311-37.031l38.957-292.229
	C448.307,179.698,447.369,176.625,445.349,174.302z"/>
           </symbol>
    </svg>
    
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
     <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    
    <div :id="svgName+dynamicIndex" v-if="this.$store.state.dynamicName ===svgName+dynamicIndex">
        <button :style="{background:'rgba(255, 202, 40, 1)' , width:'50px' ,height:'50px'}" @click="ShowElement(getterHippoBg1)" :class="this.ValueId+'_color1btn'"></button>
               
               
        <button :style="{backgroundColor:'rgba(211, 47, 47, 1)' , width:'50px' , height:'50px'}" @click="ShowElement1(getterHippoBg2)" :class="this.ValueId+'_color2btn'"></button>
    
    
        <button :style="{backgroundColor:'rgba(48, 60, 66 , 1)' , width:'50px' , height:'50px'}" @click="ShowElement2(getterHippoBg3)" :class="this.ValueId+'_color3btn'"></button>
    </div>
    <Colorpicker v-if="this.showColorPicker" :colorElement ="this.colorValue" :valueElement="this.clickedInput"/>
     <button v-if="this.showColorPicker" @click="hideElement">Close</button>
  </div>
</template>

<script>
import Colorpicker from '../colorPickerComponent'
import {
    mapState,
    mapActions,
    mapGetters,
    mapMutations
} from 'vuex';
export default {
  props:['dynamicBackground' ,'dynamicBackgroundOne', 'dynamicBackgroundTwo' , 'dynamicIndex', 'ValueId' , 'svgName'],
  components:{
        Colorpicker
    },
   computed: {
        ...mapState([ 
            'background' ,
            'background1',
            'background2', 
        ]),
        getterHippoBg1:{
            get(){
             console.log(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0])
              if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                  return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
              }

            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg2:{
            get(){
                 if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1
                 }
            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg3:{
            get(){
                 if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2
                 }
            }, 
            set(newValue){
                console.log(newValue)
            }
        }
    },
    data(){
        return{
           colorValue:'',
           showColorPicker:false,
           clickedInput:''
        }
    },
    methods:{
    ...mapActions([
    'ACTION_CHANGE_STATE',
    ]),
    ...mapMutations([
        
    ]),
    
    ShowElement(value){
        //   this.colorValue = value
          console.log(value, 'ssss')
          var ColorValue = this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
          this.colorValue = 'rgba('+ColorValue+')'
          this.showColorPicker=true
          this.clickedInput= 'One'
        //  console.log( , 'value')
      },
      ShowElement1(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1+')'
        console.log('sjahsja')
         this.clickedInput= 'Two'
          this.showColorPicker=true
      },
      ShowElement2(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2+')'
        console.log('sjahsja')
         this.clickedInput= 'Third'
          this.showColorPicker=true
      },
      hideElement(){
        this.showColorPicker=false
      }, 
    }
}
</script>

<style>

</style>