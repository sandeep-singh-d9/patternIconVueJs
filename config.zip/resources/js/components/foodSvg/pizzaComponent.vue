<template>
  <div>
   <svg  version="1.1" baseProfile="basic" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  style="display: none;">
    <symbol :id="'ic'+this.ValueId">

        <path :style="{fill:'rgba(48, 60, 66,1)' }" :class="this.ValueId+'_color1'" d="M511.266,305.456C456.776,166.3,345.714,55.238,206.557,0.748c-2.615-1.052-5.573-0.99-8.156,0.156
	c-2.594,1.135-4.635,3.25-5.667,5.885l-192,490.667c-1.542,3.948-0.604,8.427,2.396,11.427c2.042,2.042,4.76,3.125,7.542,3.125
	c1.312,0,2.625-0.24,3.885-0.729l490.667-192c2.635-1.031,4.75-3.073,5.885-5.667C512.245,311.019,512.307,308.092,511.266,305.456z
	"/>
<path :style="{fill:'rgba(255, 202, 40, 1)' }" :class="this.ValueId+'_color3'" d="M131.789,221.083c11.046,8.628,24.473,13.592,38.883,13.592c35.292,0,64-28.708,64-64
	c0-33.353-25.73-60.512-58.339-63.428l7.557-19.315c13,5.095,27.07,7.346,40.729,9.452c17.646,2.719,34.313,5.292,46.813,13.667
	c12.656,8.469,21.417,22.969,30.698,38.313c7.427,12.271,15.104,24.969,25.313,35.188c10.219,10.208,22.917,17.885,35.188,25.313
	c15.344,9.281,29.844,18.042,38.313,30.698c8.375,12.51,10.948,29.177,13.677,46.823c2.107,13.659,4.367,27.74,9.462,40.74
	l-193.827,75.845c-9.214-24.509-32.504-41.293-59.583-41.293c-35.292,0-64,28.708-64,64c0,8.228,1.732,16.241,4.775,23.783
	l-81.962,32.072L131.789,221.083z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M211.176,110.828c17.646,2.719,34.313,5.292,46.813,13.667
	c12.656,8.469,21.417,22.969,30.698,38.313c7.427,12.271,15.104,24.969,25.313,35.188c10.219,10.208,22.917,17.885,35.188,25.313
	c15.344,9.281,29.844,18.042,38.313,30.698c8.375,12.51,10.948,29.177,13.677,46.823c1.723,11.165,3.934,22.484,7.326,33.392
	l15.581-6.096c-5.095-13-7.355-27.081-9.462-40.74c-2.729-17.646-5.302-34.312-13.677-46.823
	c-8.469-12.656-22.969-21.417-38.313-30.698c-12.271-7.427-24.969-15.104-35.188-25.313c-10.208-10.219-17.885-22.917-25.313-35.188
	c-9.281-15.344-18.042-29.844-30.698-38.313c-12.5-8.375-29.167-10.948-46.813-13.667c-13.659-2.105-27.729-4.357-40.729-9.452
	l-6.095,15.579C188.702,106.899,200.012,109.106,211.176,110.828z"/>
<path style="fill:#FFB74D;" d="M443.992,320.331c-4.246-10.81-6.275-23.116-8.289-36.208c-2.958-19.167-6.021-38.99-17.031-55.438
	c-11.115-16.583-28.333-27-45-37.073c-11.708-7.083-22.76-13.771-31.146-22.146c-8.375-8.385-15.063-19.438-22.146-31.146
	c-10.073-16.667-20.49-33.885-37.073-45C266.86,82.311,247.037,79.259,227.87,76.3c-13.076-2.022-25.366-4.046-36.185-8.286
	l16.987-43.411c125.729,52.281,226.458,153.01,278.74,278.74L443.992,320.331z"/>
<path style="opacity:0.5;fill:#BCAAA4;enable-background:new    ;" d="M443.992,320.331c-4.246-10.81-6.275-23.116-8.289-36.208
	c-2.958-19.167-6.021-38.99-17.031-55.438c-11.115-16.583-28.333-27-45-37.073c-11.708-7.083-22.76-13.771-31.146-22.146
	c-8.375-8.385-15.063-19.438-22.146-31.146c-10.073-16.667-20.49-33.885-37.073-45C266.86,82.311,247.037,79.259,227.87,76.3
	c-13.076-2.022-25.366-4.046-36.185-8.286l16.987-43.411c125.729,52.281,226.458,153.01,278.74,278.74L443.992,320.331z"/>
<path :style="{fill:'rgba(48, 60, 66,1)' }" :class="this.ValueId+'_color1'" d="M268.526,315.852c3.75,0,7.865-1.146,12.552-2.563c-0.021,0.385-0.031,0.771-0.031,1.167
	c0,10.042,4.396,26.885,33.854,26.885c26.792,0,47.771-28.115,47.771-64s-20.979-64-47.771-64
	c-29.458,0-33.854,16.844-33.854,26.885c0,0.396,0.01,0.781,0.031,1.167c-4.688-1.417-8.802-2.563-12.552-2.563
	c-12.573,0-33.854,8.104-33.854,38.542C234.672,307.748,255.953,315.852,268.526,315.852z"/>
<path style="fill:#FAFAFA;" d="M268.432,260.165c1.313,0.073,5.271,1.281,7.896,2.073c9.479,2.896,18.458,5.604,25.333,0.521
	c3.406-2.531,5.354-6.51,5.354-10.937c0-6.094-2.104-9.698-4.625-12.51c0.115-2.656,1.26-4.635,12.51-4.635
	c14.333,0,26.438,19.542,26.438,42.667s-12.104,42.667-26.438,42.667c-11.073,0-12.354-1.917-12.5-4.625
	c2.396-2.646,4.615-6.271,4.615-12.521c0-4.427-1.948-8.406-5.354-10.938c-6.875-5.083-15.854-2.375-25.333,0.521
	c-2.625,0.792-6.583,2-7.802,2.073c-4.677,0-12.521-2.229-12.521-17.208C256.005,262.394,263.849,260.165,268.432,260.165z"/>
<g>
	<path :style="{fill:'rgba(48, 60, 66,1)' }" :class="this.ValueId+'_color1'" d="M149.339,320.009c11.76,0,21.333-9.573,21.333-21.333c0-11.76-9.573-21.333-21.333-21.333
		s-21.333,9.573-21.333,21.333C128.005,310.436,137.578,320.009,149.339,320.009z"/>
	<path :style="{fill:'rgba(48, 60, 66,1)' }" :class="this.ValueId+'_color1'" d="M277.339,192.009c11.76,0,21.333-9.573,21.333-21.333s-9.573-21.333-21.333-21.333
		s-21.333,9.573-21.333,21.333S265.578,192.009,277.339,192.009z"/>
</g>
<path :style="{fill:'rgba(229, 115, 115,1)' }" :class="this.ValueId+'_color2'" d="M170.672,128.009c23.531,0,42.667,19.135,42.667,42.667s-19.135,42.667-42.667,42.667
	c-11.77,0-22.525-5.012-30.563-13.522l27.997-71.551C168.97,128.209,169.796,128.009,170.672,128.009z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M195.602,136.203c5.099,7.03,8.194,15.599,8.194,24.93
	c0,23.531-19.135,42.667-42.667,42.667c-7.35,0-14.207-2.145-20.352-5.686l-0.668,1.707c8.038,8.51,18.793,13.522,30.563,13.522
	c23.531,0,42.667-19.135,42.667-42.667C213.339,156.475,206.3,143.962,195.602,136.203z"/>
<path :style="{fill:'rgba(229, 115, 115,1)' }" :class="this.ValueId+'_color2'" d="M131.541,442.595c-2.081-5.079-3.535-10.376-3.535-15.919c0-23.531,19.135-42.667,42.667-42.667
	c18.09,0,33.661,11.272,39.749,27.72L131.541,442.595z"/>
<path style="opacity:0.2;fill:#FFFFFF;enable-background:new    ;" d="M136.046,434.716c0-23.531,19.135-42.667,42.667-42.667
	c9.784,0,18.66,3.493,25.868,9.124c-7.77-10.483-20.055-17.164-33.909-17.164c-23.531,0-42.667,19.135-42.667,42.667
	c0,5.543,1.454,10.84,3.535,15.919l5.214-2.04C136.418,438.627,136.046,436.705,136.046,434.716z"/>
<linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="-42.8502" y1="635.052" x2="-25.082" y2="626.7669" gradientTransform="matrix(21.3333 0 0 -21.3333 996.2463 13791.7627)">
	<stop  offset="0" style="stop-color:#FFFFFF;stop-opacity:0.2"/>
	<stop  offset="1" style="stop-color:#FFFFFF;stop-opacity:0"/>
</linearGradient>
<path style="fill:url(#SVGID_1_);" d="M511.266,305.456C456.776,166.3,345.714,55.238,206.557,0.748
	c-2.615-1.052-5.573-0.99-8.156,0.156c-2.594,1.135-4.635,3.25-5.667,5.885l-192,490.667c-1.542,3.948-0.604,8.427,2.396,11.427
	c2.042,2.042,4.76,3.125,7.542,3.125c1.312,0,2.625-0.24,3.885-0.729l490.667-192c2.635-1.031,4.75-3.073,5.885-5.667
	C512.245,311.019,512.307,308.092,511.266,305.456z"/>
<g>
</g>
    </symbol>
   </svg>

  <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
     <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    
     <div :id="svgName+dynamicIndex" v-if="this.$store.state.dynamicName ===svgName+dynamicIndex">
        <button :style="{background:'rgba(48, 60, 66,1)' , width:'50px' ,height:'50px'}" @click="ShowElement(getterHippoBg1)" :class="this.ValueId+'_color1btn'"></button>
               
               
        <button :style="{backgroundColor:'rgba(229, 115, 115,1)' , width:'50px' , height:'50px'}" @click="ShowElement1(getterHippoBg2)" :class="this.ValueId+'_color2btn'"></button>
    
    
        <button :style="{backgroundColor:'rgba(255, 202, 40 1)' , width:'50px' , height:'50px'}" @click="ShowElement2(getterHippoBg3)" :class="this.ValueId+'_color3btn'"></button>
    </div>
    <Colorpicker v-if="this.showColorPicker" :colorElement ="this.colorValue" :valueElement="this.clickedInput"/>
     <button v-if="this.showColorPicker" @click="hideElement">Close</button>
  </div>
</template>

<script>
import Colorpicker from '../colorPickerComponent'
import {
    mapState,
    mapActions,
    mapGetters,
    mapMutations
} from 'vuex';
export default {
  props:['dynamicBackground' ,'dynamicBackgroundOne', 'dynamicBackgroundTwo' , 'dynamicIndex', 'ValueId' , 'svgName'],
  components:{
        Colorpicker
    },
   computed: {
        ...mapState([ 
            'background' ,
            'background1',
            'background2', 
        ]),
        getterHippoBg1:{
            get(){
             console.log(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0])
              
                  return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
            

            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg2:{
            get(){
               
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1
                
            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg3:{
            get(){
                
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2
                 
            }, 
            set(newValue){
                console.log(newValue)
            }
        }
    },
    data(){
        return{
           colorValue:'',
           showColorPicker:false,
           clickedInput:''
        }
    },
    methods:{
    ...mapActions([
    'ACTION_CHANGE_STATE',
    ]),
    ...mapMutations([
        
    ]),
    
    ShowElement(value){
        //   this.colorValue = value
          console.log(value, 'ssss')
          var ColorValue = this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
          this.colorValue = 'rgba('+ColorValue+')'
          this.showColorPicker=true
          this.clickedInput= 'One'
        //  console.log( , 'value')
      },
      ShowElement1(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1+')'
        console.log('sjahsja')
         this.clickedInput= 'Two'
          this.showColorPicker=true
      },
      ShowElement2(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2+')'
        console.log('sjahsja')
         this.clickedInput= 'Third'
          this.showColorPicker=true
      },
      hideElement(){
        this.showColorPicker=false
      }, 
    }
}
</script>

<style>

</style>