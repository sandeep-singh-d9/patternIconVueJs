<template>
  <div>
<svg  version="1.1" baseProfile="basic" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  style="display: none;">
    <symbol :id="'ic'+this.ValueId">
      <g>
	<path id="SVGCleanerId_0"  :style="{fill:'rgba(48, 60, 66)' }" :class="this.ValueId+'_color2'" d="M469.333,128c0-15.448-8.438-29.5-21.625-36.979
		c-2.271-19.552-17.833-35.115-37.396-37.396c-10.896-19.25-37.583-27.115-57.25-16.417c-9.104-11.24-23.958-17.552-38.688-15.49
		C306.938,8.552,292.875,0,277.333,0c-16.708,0-31.354,9.813-38.271,24.125c-3.229-1.24-6.625-2.083-10.083-2.5
		C221.5,8.438,207.458,0,192,0c-15.542,0-29.604,8.552-37.042,21.719c-13.25-1.885-26.604,2.906-35.813,12.208
		C115.104,32.646,110.917,32,106.667,32C83.146,32,64,51.135,64,74.667c0,1.885,0.125,3.771,0.375,5.635
		c-13.146,7.427-21.708,21.49-21.708,37.031s8.521,29.635,21.813,37.094c0.025,0.125,0.098,0.241,0.124,0.366l63.71,318.009
		c0.125,0.677,0.333,1.323,0.583,1.948C137.292,504.083,212.083,512,256,512c43.896,0,118.604-7.917,127.083-37.198
		c0.25-0.635,0.458-1.302,0.604-2l61.5-306.979C459.596,158.793,469.333,144.549,469.333,128z"/>
</g>
<path  :style="{fill:'rgba(211, 47, 47)' }" :class="this.ValueId+'_color1'" d="M92.283,184.363l56.613,282.605c0.25,0.667,0.438,1.365,0.563,2.094
	c0.96,2.439,6.202,5.612,14.618,8.771l-42.923-281.837C110.301,192.591,100.462,188.751,92.283,184.363z"/>
<path style="opacity:0.2;fill:#FFFFFF;enable-background:new    ;" d="M92.283,184.363l56.613,282.605
	c0.25,0.667,0.438,1.365,0.563,2.094c0.96,2.439,6.202,5.612,14.618,8.771l-42.923-281.837
	C110.301,192.591,100.462,188.751,92.283,184.363z"/>
<path  :style="{fill:'rgba(211, 47, 47)' }" :class="this.ValueId+'_color1'" d="M390.823,196.121l-42.892,281.656c8.427-3.188,13.68-6.401,14.652-8.902
	c0.125-0.729,0.313-1.427,0.563-2.083l56.534-282.236C411.479,188.965,401.608,192.759,390.823,196.121z"/>
<path style="opacity:0.1;enable-background:new    ;" d="M390.823,196.121l-42.892,281.656c8.427-3.188,13.68-6.401,14.652-8.902
	c0.125-0.729,0.313-1.427,0.563-2.083l56.534-282.236C411.479,188.965,401.608,192.759,390.823,196.121z"/>
<g>
	<path  :style="{fill:'rgba(230, 230, 230)' }" :class="this.ValueId+'_color3'" d="M154.004,204.12c-11.743-2.297-22.813-4.974-32.85-8.124l42.923,281.837
		c5.737,2.154,13.102,4.243,21.997,6.147L154.004,204.12z"/>
	<path  :style="{fill:'rgba(230, 230, 230)' }" :class="this.ValueId+'_color3'" d="M357.975,204.193l-32.057,279.772c8.898-1.914,16.271-4.016,22.013-6.188l42.892-281.656
		C380.719,199.27,369.667,201.932,357.975,204.193z"/>
</g>
<g>
	<path  :style="{fill:'rgba(211, 47, 47)' }" :class="this.ValueId+'_color1'" d="M298.775,488.384c10.305-1.148,19.177-2.707,27.143-4.419l32.057-279.772
		c-13.427,2.595-27.576,4.621-42.161,6.086L298.775,488.384z"/>
	<path  :style="{fill:'rgba(211, 47, 47)' }" :class="this.ValueId+'_color1'" d="M196.164,210.263c-14.727-1.492-28.859-3.54-42.16-6.143l32.07,279.861
		c7.961,1.706,16.831,3.259,27.132,4.405L196.164,210.263z"/>
</g>
<path  :style="{fill:'rgba(230, 230, 230)' }" :class="this.ValueId+'_color3'" d="M270.259,490.279c10.18-0.35,19.868-0.93,28.516-1.895l17.039-278.105
	c-13.083,1.313-26.358,2.241-39.611,2.677L270.259,490.279z"/>
<path style="fill:#FFFFFF;" d="M431.688,148.646c-2.708,0.656-5.042,2.354-6.521,4.719C413.292,172.354,346.792,192,256,192
	c-112.042,0-170.667-27.781-170.771-41.323c0.104-0.438,0.313-1.667,0.354-2.115c0.5-4.938-2.458-9.563-7.125-11.167
	C69.813,134.417,64,126.354,64,117.333c0-9.531,6.5-17.958,15.792-20.479c2.938-0.792,5.396-2.813,6.75-5.542
	c1.375-2.729,1.5-5.906,0.354-8.729c-1.042-2.583-1.563-5.24-1.563-7.917c0-11.76,9.563-21.333,21.333-21.333
	c3.563,0,7.063,0.969,10.417,2.875c4.896,2.833,11.25,1.24,14.292-3.573c5.354-8.5,16.104-12.323,25.875-8.396
	c2.854,1.146,6.021,1.021,8.729-0.354c2.729-1.354,4.75-3.813,5.542-6.75c2.521-9.302,10.938-15.802,20.479-15.802
	c8.979,0,17.042,5.771,20.021,14.365c1.5,4.292,6.813,6.979,11.417,6.979c5.417,0.052,10.792,1.875,14.917,5.677
	c3.021,2.771,7.396,3.552,11.167,2.042c3.813-1.531,6.417-5.094,6.688-9.188c0.75-11.146,10.021-19.875,21.125-19.875
	c9.542,0,17.958,6.5,20.479,15.802c0.792,2.938,2.813,5.396,5.542,6.75c2.688,1.375,5.875,1.49,8.729,0.354
	c11.438-4.563,23.771,1.417,27.854,12.438c1.292,3.479,4.292,6.042,7.917,6.76c3.563,0.75,7.375-0.5,9.917-3.208
	c10.313-11.198,30.646-6.802,35.583,7.469c1.5,4.292,6.813,6.979,11.417,6.979c11.563,0.156,21.896,9.354,21.729,22.521
	c-0.313,4.781,2.604,9.198,7.146,10.771C442.229,110.958,448,119.01,448,128C448,137.823,441.292,146.313,431.688,148.646z"/>
<path  :style="{fill:'rgba(230, 230, 230)' }" :class="this.ValueId+'_color3'" d="M241.71,490.279l-5.945-277.336c-13.44-0.44-26.672-1.371-39.6-2.68l17.042,278.122
	C221.85,489.348,231.534,489.928,241.71,490.279z"/>
<path  :style="{fill:'rgba(211, 47, 47)' }" :class="this.ValueId+'_color1'" d="M256,213.333c-6.755,0-13.504-0.171-20.236-0.391l5.945,277.336c4.703,0.161,9.277,0.388,14.29,0.388
	c5.003,0,9.566-0.227,14.259-0.388l5.944-277.323C269.432,213.178,262.672,213.333,256,213.333z"/>
<g>
	<path  :style="{fill:'rgba(48, 60, 66)' }" :class="this.ValueId+'_color2'" d="M181.333,85.333c5.896,0,10.667-4.771,10.667-10.667C192,68.771,187.229,64,181.333,64
		c-17.646,0-32,14.354-32,32c0,5.896,4.771,10.667,10.667,10.667c5.896,0,10.667-4.771,10.667-10.667
		C170.667,90.115,175.458,85.333,181.333,85.333z"/>
	<path  :style="{fill:'rgba(48, 60, 66)' }" :class="this.ValueId+'_color2'" d="M330.667,85.333c-17.646,0-32,14.354-32,32c0,5.896,4.771,10.667,10.667,10.667
		S320,123.229,320,117.333c0-5.885,4.792-10.667,10.667-10.667c5.896,0,10.667-4.771,10.667-10.667
		C341.333,90.104,336.563,85.333,330.667,85.333z"/>
	<path  :style="{fill:'rgba(48, 60, 66)' }" :class="this.ValueId+'_color2'" d="M373.333,106.667c-5.896,0-10.667,4.771-10.667,10.667S367.438,128,373.333,128
		c5.875,0,10.667,4.781,10.667,10.667c0,5.896,4.771,10.667,10.667,10.667c5.896,0,10.667-4.771,10.667-10.667
		C405.333,121.021,390.979,106.667,373.333,106.667z"/>
	<path  :style="{fill:'rgba(48, 60, 66)' }" :class="this.ValueId+'_color2'" d="M245.333,128c-5.896,0-10.667,4.771-10.667,10.667s4.771,10.667,10.667,10.667
		c5.875,0,10.667,4.781,10.667,10.667c0,5.896,4.771,10.667,10.667,10.667c5.896,0,10.667-4.771,10.667-10.667
		C277.333,142.354,262.979,128,245.333,128z"/>
	<path  :style="{fill:'rgba(48, 60, 66)' }" :class="this.ValueId+'_color2'" d="M202.667,106.667c-17.646,0-32,14.354-32,32c0,5.896,4.771,10.667,10.667,10.667
		c5.896,0,10.667-4.771,10.667-10.667c0-5.885,4.792-10.667,10.667-10.667c5.896,0,10.667-4.771,10.667-10.667
		S208.563,106.667,202.667,106.667z"/>
	<circle  :style="{fill:'rgba(48, 60, 66)' }" :class="this.ValueId+'_color2'" cx="256" cy="341.333" r="85.333"/>
</g>
<circle style="fill:#F2F2F2;" cx="256" cy="341.333" r="64"/>
<path style="opacity:0.4;fill:#FFFFFF;enable-background:new    ;" d="M202.667,352c0-35.292,28.708-64,64-64
	c14.926,0,28.493,5.346,39.391,13.943c-11.729-14.868-29.691-24.609-50.057-24.609c-35.292,0-64,28.708-64,64
	c0,20.366,9.741,38.328,24.609,50.057C208.013,380.493,202.667,366.926,202.667,352z"/>
<g>
	<g>
		
			<linearGradient id="SVGCleanerId_0_3_" gradientUnits="userSpaceOnUse" x1="-45.6262" y1="639.4435" x2="-25.9231" y2="630.2534" gradientTransform="matrix(21.3333 0 0 -21.3333 996.3334 13791.667)">
			<stop  offset="0" style="stop-color:#FFFFFF;stop-opacity:0.2"/>
			<stop  offset="1" style="stop-color:#FFFFFF;stop-opacity:0"/>
		</linearGradient>
		<path id="SVGCleanerId_0_1_" style="fill:url(#SVGCleanerId_0_3_);" d="M469.333,128c0-15.448-8.438-29.5-21.625-36.979
			c-2.271-19.552-17.833-35.115-37.396-37.396c-10.896-19.25-37.583-27.115-57.25-16.417c-9.104-11.24-23.958-17.552-38.688-15.49
			C306.938,8.552,292.875,0,277.333,0c-16.708,0-31.354,9.813-38.271,24.125c-3.229-1.24-6.625-2.083-10.083-2.5
			C221.5,8.438,207.458,0,192,0c-15.542,0-29.604,8.552-37.042,21.719c-13.25-1.885-26.604,2.906-35.813,12.208
			C115.104,32.646,110.917,32,106.667,32C83.146,32,64,51.135,64,74.667c0,1.885,0.125,3.771,0.375,5.635
			c-13.146,7.427-21.708,21.49-21.708,37.031s8.521,29.635,21.813,37.094c0.025,0.125,0.098,0.241,0.124,0.366l63.71,318.009
			c0.125,0.677,0.333,1.323,0.583,1.948C137.292,504.083,212.083,512,256,512c43.896,0,118.604-7.917,127.083-37.198
			c0.25-0.635,0.458-1.302,0.604-2l61.5-306.979C459.596,158.793,469.333,144.549,469.333,128z"/>
	</g>
	<g>
		
			<linearGradient id="SVGCleanerId_0_4_" gradientUnits="userSpaceOnUse" x1="-45.6262" y1="639.4435" x2="-25.9231" y2="630.2534" gradientTransform="matrix(21.3333 0 0 -21.3333 996.3334 13791.667)">
			<stop  offset="0" style="stop-color:#FFFFFF;stop-opacity:0.2"/>
			<stop  offset="1" style="stop-color:#FFFFFF;stop-opacity:0"/>
		</linearGradient>
		<path id="SVGCleanerId_0_2_" style="fill:url(#SVGCleanerId_0_4_);" d="M469.333,128c0-15.448-8.438-29.5-21.625-36.979
			c-2.271-19.552-17.833-35.115-37.396-37.396c-10.896-19.25-37.583-27.115-57.25-16.417c-9.104-11.24-23.958-17.552-38.688-15.49
			C306.938,8.552,292.875,0,277.333,0c-16.708,0-31.354,9.813-38.271,24.125c-3.229-1.24-6.625-2.083-10.083-2.5
			C221.5,8.438,207.458,0,192,0c-15.542,0-29.604,8.552-37.042,21.719c-13.25-1.885-26.604,2.906-35.813,12.208
			C115.104,32.646,110.917,32,106.667,32C83.146,32,64,51.135,64,74.667c0,1.885,0.125,3.771,0.375,5.635
			c-13.146,7.427-21.708,21.49-21.708,37.031s8.521,29.635,21.813,37.094c0.025,0.125,0.098,0.241,0.124,0.366l63.71,318.009
			c0.125,0.677,0.333,1.323,0.583,1.948C137.292,504.083,212.083,512,256,512c43.896,0,118.604-7.917,127.083-37.198
			c0.25-0.635,0.458-1.302,0.604-2l61.5-306.979C459.596,158.793,469.333,144.549,469.333,128z"/>
	</g>
</g>
    </symbol>
    </svg>

    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
     <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    <svg viewBox="0 0 2000 1000" xmlns:xlink="http://www.w3.org/1999/xlink">
    <use :class="this.ValueId" :href="'#ic'+this.ValueId" x="0" y="0" />
    </svg>
    
    <div :id="svgName+dynamicIndex" v-if="this.$store.state.dynamicName ===svgName+dynamicIndex">
        <button :style="{background:'rgba(211, 47, 47 , 1)' , width:'50px' ,height:'50px'}" @click="ShowElement(getterHippoBg1)" :class="this.ValueId+'_color1btn'"></button>
               
               
        <button :style="{backgroundColor:'rgba(48, 60, 66 , 1)' , width:'50px' , height:'50px'}" @click="ShowElement1(getterHippoBg2)" :class="this.ValueId+'_color2btn'"></button>
    
    
        <button :style="{backgroundColor:'rgba(230, 230, 230 , 1)' , width:'50px' , height:'50px'}" @click="ShowElement2(getterHippoBg3)" :class="this.ValueId+'_color3btn'"></button>
    </div>
    <Colorpicker v-if="this.showColorPicker" :colorElement ="this.colorValue" :valueElement="this.clickedInput"/>
     <button v-if="this.showColorPicker" @click="hideElement">Close</button>
  </div>
</template>

<script>
import Colorpicker from '../colorPickerComponent'
import {
    mapState,
    mapActions,
    mapGetters,
    mapMutations
} from 'vuex';
export default {
  props:['dynamicBackground' ,'dynamicBackgroundOne', 'dynamicBackgroundTwo' , 'dynamicIndex', 'ValueId' , 'svgName'],
  components:{
        Colorpicker
    },
   computed: {
        ...mapState([ 
            'background' ,
            'background1',
            'background2', 
        ]),
        getterHippoBg1:{
            get(){
             console.log(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0])
              if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                  return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
              }

            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg2:{
            get(){
                 if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1
                 }
            }, 
            set(newValue){
                console.log(newValue)
            }
        },
        getterHippoBg3:{
            get(){
                 if(this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].name==='Hippo'){
                     return this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2
                 }
            }, 
            set(newValue){
                console.log(newValue)
            }
        }
    },
    data(){
        return{
           colorValue:'',
           showColorPicker:false,
           clickedInput:''
        }
    },
    methods:{
    ...mapActions([
    'ACTION_CHANGE_STATE',
    ]),
    ...mapMutations([
        
    ]),
    
    ShowElement(value){
        //   this.colorValue = value
          console.log(value, 'ssss')
          var ColorValue = this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background
          this.colorValue = 'rgba('+ColorValue+')'
          this.showColorPicker=true
          this.clickedInput= 'One'
        //  console.log( , 'value')
      },
      ShowElement1(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background1+')'
        console.log('sjahsja')
         this.clickedInput= 'Two'
          this.showColorPicker=true
      },
      ShowElement2(value){
            this.colorValue = 'rgba('+this.$store.state.SvgComponent[this.$store.state.dynamicIndex][0].background2+')'
        console.log('sjahsja')
         this.clickedInput= 'Third'
          this.showColorPicker=true
      },
      hideElement(){
        this.showColorPicker=false
      }, 
    }
}
</script>

<style>

</style>